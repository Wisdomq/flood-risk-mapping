# FLOOD-MAPPING CNN Architecture Overview

This document describes the internal architecture, including:
- Data preprocessing workflow
- CNN encoder–decoder pipeline
- Attention modules (BAM, CoordAtt)
- Training configuration
- API routing structure


## Expanded Architecture Details

### Project Modules
- `model/app/app.py`  
  Flask app (if present) or main entrypoint for scripts: orchestrates training and inference utilities.

- `model/app/data_preprocessing.py`  
  Data loader and preprocessing utilities for NetCDF (`rain.nc`, `t.nc`) and spatial normalization, tiling, and temporal stacking.

- `model/app/models.py`  
  Model definitions: FLOOD-MAPPING CNN architecture classes, encoder/decoder blocks, attention modules.

- `model/app/train_model.py` and `model/app/services/train_model.py`  
  Training loop, checkpointing, callbacks, evaluation logging, and hyperparameter management.

- `model/app/services/deep_learning.py`  
  Core model helper functions (losses, metrics, model builders).

- `model/app/services/BAM.py`, `DWConv.py`, `coordatt.py`, `SWBCE.py`  
  Custom modules implementing attention, depthwise conv, coordinate attention, and custom loss.

### Data Flow
1. **Data ingestion**: NetCDF files are loaded via `data_preprocessing.py` using xarray/netCDF4. Files are parsed into tensors with shape `(time, channels, H, W)`.
2. **Preprocessing**: Normalization, missing value handling, and temporal windowing (sequence length) are applied.
3. **Model Input**: The FLOOD-MAPPING CNN receives stacked channels (rain, temperature, topographic covariates).
4. **Prediction**: The decoder outputs per-grid flood risk scores; these are thresholded into categories (low/medium/high).
5. **Postprocessing**: Outputs are reprojected into geospatial rasters and visualized.

### Training Details
- Optimizer: Adam
- Learning rate schedule: configurable in `model/config.py`
- Loss: combined SWBCE + MSE hybrid (see `SWBCE.py`)
- Metrics: MAE, MSE, R², Accuracy

### Reproducibility
- `model/requirements.txt` pins core dependencies.
- Random seeds are set inside `train_model.py` for reproducible runs.
- Checkpoints saved under `model/checkpoints/` (create-directory on first run).

### How to run (example)
```bash
pip install -r model/requirements.txt
python model/run.py --mode train --config model/config.py
python model/run.py --mode predict --input data/rain.nc --output results/prediction.tif
```

### Notes on Large Data
- Raw NetCDF files should be kept out of the repo (`data/` is gitignored).
- Use external storage (GCP bucket or local path) and supply `DATA_PATH` in config.

