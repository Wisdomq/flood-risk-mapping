# FLOOD-MAPPING CNN: Flood Risk Mapping Using Deep Learning
## Abstract
This repository presents the FLOOD-MAPPING CNN, a deep learning architecture developed for high‑resolution flood susceptibility and rainfall‑driven flood risk mapping over the Tokachi River Basin, Obihiro, Hokkaido, Japan. The model integrates spatial rainfall fields and geospatial covariates to predict flood‑prone zones at 5 km resolution using a convolutional encoder–decoder variant with attention mechanisms.

## Introduction
Flooding remains among the most damaging natural hazards in Japan. This project develops a deep learning pipeline capable of learning spatial rainfall–flood relationships and generating predictive flood risk maps. The FLOOD-MAPPING CNN was trained using historical rainfall, maximum 72‑hour precipitation records, and region-specific environmental factors.

## Study Area
The Tokachi River Basin in Obihiro, Hokkaido, is characterized by recurrent heavy rainfall events and diverse topographic variation, making it ideal for flood risk modeling.

## Dataset Description
The dataset consists of:
- 719 temporal slices (1951–2010)
- 5 km spatial resolution grids (221 × 171)
- Derived annual maximum 72-hour rainfall
- Dynamic downscaled climate scenarios (Historical, +2K, +4K)

## Methodology
The pipeline includes:
1. Data preprocessing and normalization  
2. Spatial feature extraction using CNN encoders  
3. Attention-enhanced decoding using custom modules (BAM, DWConv, CoordAtt)  
4. Grid‑level flood risk prediction  
5. Post‑processing and geospatial reconstruction  

## FLOOD-MAPPING CNN Architecture
The model integrates:
- Convolutional encoders  
- Dual attention modules  
- Lightweight spatial weighting (SWBCE)  
- Custom CoordAtt and BAM modules  
- Symmetric decoder for map reconstruction  

## Training Strategy
- Loss: Weighted BCE / MSE hybrid  
- Optimizer: Adam  
- Metrics: MAE, MSE, R²  
- Temporal batch construction based on rainfall sequences  

## Experiments & Evaluation
The model achieved:
- R² Score: 0.67
- MAE: 0.17
- Accuracy: 51.92%

## Conclusion
The FLOOD-MAPPING CNN offers a robust approach for rainfall‑driven flood susceptibility mapping and is extendable to future climate scenarios.

## How to Run
```bash
pip install -r model/requirements.txt
python model/run.py
```

## Reproducibility
All code, preprocessing scripts, and model definitions are included in the `model/` directory.

## License
MIT License.
