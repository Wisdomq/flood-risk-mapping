# model/app

Contains model definitions, training scripts, and preprocessing utilities.
