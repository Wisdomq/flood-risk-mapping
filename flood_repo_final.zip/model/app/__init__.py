# app/__init__.py

from flask import Flask, render_template
from app.routes.api.v1 import api_v1
from app.services.deep_learning import load_model


def create_app():
    app = Flask(__name__, template_folder='templates')
    app.config.from_object('config')

    # Load the model at startup
    load_model()

    # Register blueprint
    app.register_blueprint(api_v1, url_prefix='/api/v1')

    # Define root route
    @app.route('/')
    def index():
        return render_template('index.html')
  

    return app
