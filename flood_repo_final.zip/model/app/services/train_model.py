import os
import numpy as np
import netCDF4 as nc
import torch
import torch.nn as nn
import torch.optim as optim
from torch.utils.data import DataLoader, TensorDataset
import torchvision
import torch.utils.model_zoo as model_zoo
from sklearn.model_selection import train_test_split
import matplotlib.pyplot as plt
import json
import math
from BAM import BAM
from coordatt import CoordAtt
from DWConv import DWConv
import torchvision.models as models

# Define constants based on the ctl file
X_DIM = 221
Y_DIM = 171
Z_DIM = 1
TIME_STEPS = 719
X_START = 137
X_INC = 0.05
Y_START = 38.5
Y_INC = 0.05
UNDEF_VALUE = -999.9

high_threshold = 290
medium_threshold = 270

def load_and_preprocess_data(folder_path):
    file_paths = [os.path.join(folder_path, file) for file in os.listdir(folder_path) if file.endswith('.nc')]
    rain_data_list = []
    labels_list = []
    bboxes_list = []

    for file_path in file_paths:
        data = nc.Dataset(file_path)
        rain_data = data.variables['t'][:]  # Rainfall data
        time_values = data.variables['time'][:]  # Time values
        data.close()

        # Ensure rain_data has the correct shape
        if rain_data.ndim == 3:
            rain_data = np.expand_dims(rain_data, axis=1)  # Add channel dimension
        elif rain_data.ndim == 4 and rain_data.shape[1] == 1:
            pass  # rain_data already has the correct shape
        else:
            raise ValueError(f"Unexpected rain_data shape: {rain_data.shape}")

        rain_data_tensor = torch.tensor(rain_data, dtype=torch.float32)

        # Generate labels based on thresholds
        labels = np.zeros(len(time_values))
        for i in range(len(time_values)):
            total_rainfall = np.sum(rain_data[i])
            if total_rainfall >= high_threshold:
                labels[i] = 2
            elif total_rainfall >= medium_threshold:
                labels[i] = 1
            else:
                labels[i] = 0

        labels_tensor = torch.tensor(labels, dtype=torch.long)

        # Example bounding boxes (adjust as per actual implementation)
        bboxes = np.array([[X_START, Y_START, X_START + (X_DIM * X_INC), Y_START + (Y_DIM * Y_INC)]] * len(time_values))
        bboxes_tensor = torch.tensor(bboxes, dtype=torch.float32)

        rain_data_list.append(rain_data_tensor)
        labels_list.append(labels_tensor)
        bboxes_list.append(bboxes_tensor)

    # Convert lists to tensors and handle empty cases
    if rain_data_list:
        rain_data = torch.cat(rain_data_list, dim=0)
    else:
        rain_data = torch.tensor([])

    if labels_list:
        labels = torch.cat(labels_list, dim=0)
    else:
        labels = torch.tensor([])

    if bboxes_list:
        bboxes = torch.cat(bboxes_list, dim=0)
    else:
        bboxes = torch.tensor([])

    return list(zip(rain_data, labels, bboxes))

# Define your complex CNN model
class ResNet34(nn.Module):
    def __init__(self):
        super(ResNet34, self).__init__()
        self.model = torchvision.models.resnet34(pretrained=True)
        self.model.conv1 = nn.Conv2d(3, 64, kernel_size=7, stride=2, padding=3, bias=False)  # Adjust to 3 channels
        
        for m in self.modules():
            if isinstance(m, nn.Conv2d):
                n = m.kernel_size[0] * m.kernel_size[1] * m.out_channels
                m.weight.data.normal_(0, math.sqrt(2. / n))
            elif isinstance(m, nn.BatchNorm2d):
                m.weight.data.fill_(1)
                m.bias.data.zero_()

    def forward(self, x):
        feature = []
        x = self.model.conv1(x)
        x = self.model.bn1(x)
        x = self.model.relu(x)
        feature.append(x)
        x = self.model.maxpool(x)
        x = self.model.layer1(x)
        feature.append(x)
        x = self.model.layer2(x)
        feature.append(x)
        x = self.model.layer3(x)
        feature.append(x)
        x = self.model.layer4(x)
        feature.append(x)
        return feature
    
    def _make_layer(self, block, planes, blocks, stride=1):
        downsample = None
        if stride != 1 or self.inplanes != planes * block.expansion:
            downsample = nn.Sequential(
                nn.Conv2d(self.inplanes, planes * block.expansion,
                          kernel_size=1, stride=stride, bias=False),
                nn.BatchNorm2d(planes * block.expansion),
            )

        layers = []
        layers.append(block(self.inplanes, planes, stride, downsample))
        self.inplanes = planes * block.expansion
        for i in range(1, blocks):
            layers.append(block(self.inplanes, planes))

        return nn.Sequential(*layers)

    def _load_pretrained_model(self, model_path):
        pretrain_dict = model_zoo.load_url(model_path)
        model_dict = {}
        state_dict = self.state_dict()
        for k, v in pretrain_dict.items():
            if k in state_dict:
                model_dict[k] = v
        state_dict.update(model_dict)
        self.load_state_dict(state_dict)


class zh_net(nn.Module):
    def __init__(self, freeze_bn=False):
        super(zh_net, self).__init__()
        self.encoder = ResNet34()  # Use the modified ResNet34
        self.decoder = Decoder()

        if freeze_bn:
            self.freeze_bn()

    def forward(self, A, B=None, C=None):
        if B is None:
            B = torch.zeros_like(A)  # Default value for B if not provided
        if C is None:
            C = torch.zeros_like(A)  # Default value for C if not provided

        combined_input = torch.cat((A, B, C), dim=1)
        features = self.encoder(combined_input)
        result = self.decoder(features, combined_input)
        return result

    def freeze_bn(self):
        for m in self.modules():
            if isinstance(m, nn.BatchNorm2d):
                m.eval()

class decoder_block(nn.Module):
    def __init__(self, in_channels, out_channels):
        super(decoder_block, self).__init__()

        self.de_block1 = nn.Sequential(
            nn.Conv2d(in_channels, out_channels, kernel_size=1),
            nn.BatchNorm2d(out_channels),
            nn.ReLU())

        self.de_block2 = DWConv(out_channels, out_channels)

        self.att = CoordAtt(out_channels, out_channels)

        self.de_block3 = DWConv(out_channels, out_channels)

        self.de_block4 = nn.Conv2d(out_channels, 1, 1)

        self.de_block5 = nn.ConvTranspose2d(out_channels, out_channels, kernel_size=2, stride=2)

    def forward(self, input1, input, input2):
        # Add debug statements to check the sizes of inputs
        print(f"input1 size: {input1.size()}, input size: {input.size()}, input2 size: {input2.size()}")
        x0 = torch.cat((input1, input, input2), dim=1)
        x0 = self.de_block1(x0)
        x = self.de_block2(x0)
        x = self.att(x)
        x = self.de_block3(x)
        x = x + x0
        al = self.de_block4(x)
        x = self.de_block5(x)
        return al, x

class Decoder(nn.Module):
    def __init__(self):
        super(Decoder, self).__init__()
        self.de_block0 = decoder_block(512, 256)
        self.de_block1 = decoder_block(256, 128)
        self.de_block2 = decoder_block(128, 64)
        self.de_block3 = decoder_block(64, 64)
        self.de_block4 = decoder_block(64, 64)

    def forward(self, feature, B):
        A, x = self.de_block0(feature[4], feature[3], B)
        B, x = self.de_block1(x, feature[2], B)
        C, x = self.de_block2(x, feature[1], B)
        D, x = self.de_block3(x, feature[0], B)
        E, x = self.de_block4(x, feature[0], B)
        return E, D, C, B, A

def train_model(folder_path):
    # Load and preprocess data
    data = load_and_preprocess_data(folder_path)
    
    if not data:
        raise ValueError("No data found in the specified folder path")

    # Convert to DataLoader
    rain_data_list = []
    labels_list = []
    bboxes_list = []

    for rain_data_tensor, labels_tensor, bboxes_tensor in data:
        if rain_data_tensor.numel() > 0 and labels_tensor.numel() > 0 and bboxes_tensor.numel() > 0:
            rain_data_list.append(rain_data_tensor)
            labels_list.append(labels_tensor)
            bboxes_list.append(bboxes_tensor)
        else:
            print(f"Skipping empty tensor: rain_data_tensor size: {rain_data_tensor.size()}, labels_tensor size: {labels_tensor.size()}, bboxes_tensor size: {bboxes_tensor.size()}")

    # Check sizes before concatenation
    print(f"Rain data sizes: {[tensor.size() for tensor in rain_data_list]}")
    print(f"Labels sizes: {[tensor.size() for tensor in labels_list]}")
    print(f"Bboxes sizes: {[tensor.size() for tensor in bboxes_list]}")

    # Ensure tensor dimensions are consistent
    rain_data_list = [tensor.unsqueeze(0) if tensor.ndimension() == 0 else tensor for tensor in rain_data_list]
    labels_list = [tensor.unsqueeze(0) if tensor.ndimension() == 0 else tensor for tensor in labels_list]
    bboxes_list = [tensor.unsqueeze(0) if tensor.ndimension() == 0 else tensor for tensor in bboxes_list]

    if rain_data_list:
        rain_data = torch.cat(rain_data_list, dim=0)
    else:
        rain_data = torch.tensor([])

    if labels_list:
        labels = torch.cat(labels_list, dim=0)
    else:
        labels = torch.tensor([])

    if bboxes_list:
        bboxes = torch.cat(bboxes_list, dim=0)
    else:
        bboxes = torch.tensor([])

    # Verify sizes match
    if rain_data.size(0) != labels.size(0) or rain_data.size(0) != bboxes.size(0):
        print(f"rain_data size: {rain_data.size()}, labels size: {labels.size()}, bboxes size: {bboxes.size()}")
        raise ValueError("Size mismatch between tensors after concatenation")

    dataset = TensorDataset(rain_data, labels, bboxes)
    
    # Split data into train and test
    train_data, test_data = train_test_split(dataset, test_size=0.2, random_state=42)

    # Define DataLoader for training
    train_loader = DataLoader(train_data, batch_size=32, shuffle=True)
    test_loader = DataLoader(test_data, batch_size=32, shuffle=False)

    # Initialize model, optimizer, and loss function
    model = zh_net()
    optimizer = optim.Adam(model.parameters(), lr=0.0001)
    criterion = nn.CrossEntropyLoss()

    # Training loop
    num_epochs = 10
    history = {'loss': [], 'val_loss': [], 'accuracy': [], 'val_accuracy': []}

    for epoch in range(num_epochs):
        model.train()
        for rain_data_tensor, labels_tensor, bboxes_tensor in train_loader:  # Unpack data
            optimizer.zero_grad()  # Zero the gradients
            outputs = model(rain_data_tensor)  # Forward pass with only rain_data_tensor
            loss = criterion(outputs, labels_tensor)  # Calculate the loss
            loss.backward()  # Backward pass
            optimizer.step()  # Update the parameters

        model.eval()
        with torch.no_grad():
            test_loss = 0
            correct = 0
            total = 0
            for rain_data_tensor, labels_tensor, bboxes_tensor in test_loader:  # Unpack data
                outputs = model(rain_data_tensor)  # Forward pass with only rain_data_tensor
                test_loss += criterion(outputs, labels_tensor).item()
                _, predicted = torch.max(outputs, 1)
                total += labels_tensor.size(0)
                correct += (predicted == labels_tensor).sum().item()

            accuracy = correct / total
            history['loss'].append(loss.item())
            history['val_loss'].append(test_loss / len(test_loader))
            history['accuracy'].append(accuracy)

        print(f'Epoch [{epoch+1}/{num_epochs}], Loss: {loss.item():.4f}, Val Loss: {test_loss/len(test_loader):.4f}, Accuracy: {accuracy:.4f}')

    # Save model predictions and bounding boxes
    model.eval()
    predictions = []
    bboxes_list = []
    with torch.no_grad():
        for rain_data_tensor, labels_tensor, bboxes_tensor in test_loader:  # Unpack data
            outputs = model(rain_data_tensor)  # Forward pass with only rain_data_tensor
            _, predicted = torch.max(outputs, 1)
            predictions.extend(predicted.cpu().numpy())
            bboxes_list.extend(bboxes_tensor.cpu().numpy())

    np.save('predictions.npy', np.array(predictions))
    np.save('bboxes.npy', np.array(bboxes_list))

    return model, history

# Main function
def main():
    folder_path = 'C:\\Users\\Wiz Mboya\\Desktop\\Flood Analysis and Mapping\\DATA\\tdata\\'
    model, history = train_model(folder_path)

    # Save the predictions to a JSON file for the frontend
    predictions = np.load('predictions.npy').tolist()
    with open('predictions.json', 'w') as f:
        json.dump(predictions, f)

    # Plotting the loss and accuracy
    plt.figure(figsize=(12, 5))
    plt.subplot(1, 2, 1)
    plt.plot(history['loss'], label='Training Loss')
    plt.plot(history['val_loss'], label='Validation Loss')
    plt.legend()
    plt.title('Loss over Epochs')

    plt.subplot(1, 2, 2)
    plt.plot(history['accuracy'], label='Training Accuracy')
    plt.plot(history['val_accuracy'], label='Validation Accuracy')
    plt.legend()
    plt.title('Accuracy over Epochs')
    plt.show()

if __name__ == "__main__":
    main()

