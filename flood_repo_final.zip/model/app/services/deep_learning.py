# app/services/deep_learning.py

import numpy as np
import tensorflow as tf

def load_model():
    global model
    model = tf.keras.models.load_model('C:\\Users\\Wiz Mboya\\Desktop\\Flood Analysis and Mapping\\CODE\\model.h5')
    return model

def predict(input_data):
    input_array = np.array(input_data).reshape(1, -1)  # Adjust shape as needed
    predictions = model.predict(input_array)
    return predictions
