# data_preprocessing.py

import netCDF4 as nc
import numpy as np
from sklearn.model_selection import train_test_split

def load_and_preprocess_data(file_path):
    # Open the NetCDF file
    data = nc.Dataset(file_path)

    # Access the 'rain' variable and time values
    rain_data = data.variables['t'][:]
    time_values = data.variables['time'][:]

    # Close the NetCDF file
    data.close()

    # Set thresholds for high, medium, and low rainfall
    high_threshold = 288  # Replace with your desired threshold for high rainfall
    medium_threshold = 281  # Replace with your desired threshold for medium rainfall

    # Categorize rainfall values into high, medium, and low
    labels = np.zeros((len(time_values),))
    for i in range(len(time_values)):
        total_rainfall = np.sum(rain_data[i])  # Sum all rainfall values for a particular time index
        if total_rainfall >= high_threshold:
            labels[i] = 2  # High rainfall
        elif total_rainfall >= medium_threshold:
            labels[i] = 1  # Medium rainfall
        else:
            labels[i] = 0  # Low rainfall

    # Reshape the data to fit the model's input requirements (e.g., flatten or select specific dimensions)
    reshaped_data = np.reshape(rain_data, (rain_data.shape[0], -1))  # Flatten the data

    # Split the data and labels into training and testing sets
    X_train, X_test, y_train, y_test = train_test_split(reshaped_data, labels, test_size=0.2, random_state=42)

    return X_train, X_test, y_train, y_test
