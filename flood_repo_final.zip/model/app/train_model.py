# train_model.py

from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.optimizers import Adam
import matplotlib.pyplot as plt
import netCDF4 as nc
import numpy as np
from sklearn.model_selection import train_test_split
import os
import json

# Path to your .nc file
data_folder = 'C:\\Users\\Wiz Mboya\\Desktop\\Flood Analysis and Mapping\\DATA\\tdata\\'

# Bounding box constants
BOUNDING_BOX = {
    "min_latitude": 38.5,
    "max_latitude": 46.0,
    "min_longitude": 137.0,
    "max_longitude": 148.0
}

# Function to load and preprocess data
def load_and_preprocess_data(folder_path):
    file_paths = [os.path.join(folder_path, file) for file in os.listdir(folder_path) if file.endswith('.nc')]
    all_rain_data = []
    all_time_values = []

    for file_path in file_paths:
        data = nc.Dataset(file_path)
        rain_data = data.variables['t'][:]
        time_values = data.variables['time'][:]
        data.close()
        
        all_rain_data.append(rain_data)
        all_time_values.append(time_values)

    all_rain_data = np.concatenate(all_rain_data, axis=0)
    all_time_values = np.concatenate(all_time_values, axis=0)

    high_threshold = 288
    medium_threshold = 281
    labels = np.zeros((len(all_time_values),))
    for i in range(len(all_time_values)):
        total_rainfall = np.sum(all_rain_data[i])
        if total_rainfall >= high_threshold:
            labels[i] = 2
        elif total_rainfall >= medium_threshold:
            labels[i] = 1
        else:
            labels[i] = 0

    reshaped_data = np.reshape(all_rain_data, (all_rain_data.shape[0], -1))
    X_train, X_test, y_train, y_test = train_test_split(reshaped_data, labels, test_size=0.2, random_state=42)
    return X_train, X_test, y_train, y_test

# Load and preprocess data
X_train, X_test, y_train, y_test = load_and_preprocess_data(data_folder)

# Define the model architecture
model = Sequential()
model.add(Dense(256, activation='relu', input_shape=(X_train.shape[1],)))
model.add(Dropout(0.5))
model.add(Dense(128, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(64, activation='relu'))
model.add(Dropout(0.5))
model.add(Dense(32, activation='relu'))
model.add(Dense(3, activation='softmax'))

# Compile the model
model.compile(optimizer=Adam(learning_rate=0.0001), loss='sparse_categorical_crossentropy', metrics=['accuracy'])

# Train the model
history = model.fit(X_train, y_train, epochs=20, batch_size=32, validation_split=0.2)

# Evaluate the model on test data
test_loss, test_accuracy = model.evaluate(X_test, y_test)
print(f"Test Loss: {test_loss}, Test Accuracy: {test_accuracy}")

# Save the model
model.save('C:\\Users\\Wiz Mboya\\Desktop\\Flood Analysis and Mapping\\CODE\\model.h5')

# Make predictions on the test set
predictions = model.predict(X_test)
predicted_labels = np.argmax(predictions, axis=1)

# Save predictions to a JSON file
results = []
for i, label in enumerate(predicted_labels):
    results.append({
        "latitude": np.random.uniform(BOUNDING_BOX['min_latitude'], BOUNDING_BOX['max_latitude']),
        "longitude": np.random.uniform(BOUNDING_BOX['min_longitude'], BOUNDING_BOX['max_longitude']),
        "rainfall_category": int(label)
    })

with open('C:\\Users\\Wiz Mboya\\Desktop\\Flood Analysis and Mapping\\CODE\\predictions.json', 'w') as f:
    json.dump(results, f, indent=4)

