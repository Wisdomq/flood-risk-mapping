# config.py

class Config:
    DEBUG = True
    # Add other configuration settings as needed

# Optionally, use environment-specific configurations
class ProductionConfig(Config):
    DEBUG = False

class DevelopmentConfig(Config):
    DEBUG = True

class TestingConfig(Config):
    TESTING = True
